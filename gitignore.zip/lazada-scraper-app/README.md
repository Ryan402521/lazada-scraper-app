# Lazada Scraper GUI App 🛒

A Python desktop GUI app that scrapes real-time product data from Lazada PH.

## ✅ Features
- Scrape by keyword and page count
- Extract Name, Price, Sold, Link
- GUI with Treeview and sorting
- CAPTCHA detection & manual solve alert
- Save as CSV with auto open

## 🧰 Requirements

```bash
pip install -r requirements.txt
```

## 🚀 How to Run

```bash
python lazada_scraper_app.py
```

> Note: Make sure Google Chrome is installed.
