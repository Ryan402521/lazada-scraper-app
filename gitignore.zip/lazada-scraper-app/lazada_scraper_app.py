import csv
import os
import re
import webbrowser
import time
from tkinter import *
from tkinter import filedialog, messagebox, ttk
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup

original_data = []
recent_data = []

def sold_to_number(sold_str):
    try:
        if 'k' in sold_str.lower():
            return float(sold_str.lower().replace('k', '').replace('sold', '').strip()) * 1000
        return float(re.sub(r'[^\d.]', '', sold_str))
    except:
        return 0

def check_captcha(driver):
    try:
        if "captcha" in driver.current_url.lower() or "Please verify" in driver.page_source:
            messagebox.showwarning("CAPTCHA Detected", "Please solve the CAPTCHA manually and click OK.")
            while "captcha" in driver.current_url.lower() or "Please verify" in driver.page_source:
                driver.implicitly_wait(5)
    except:
        pass

def scrape_lazada(keyword, max_pages, sort_choice):
    global recent_data, original_data
    options = webdriver.ChromeOptions()
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
    wait = WebDriverWait(driver, 10)

    driver.get("https://www.lazada.com.ph/")

    try:
        search_box = wait.until(EC.presence_of_element_located((By.ID, 'q')))
        search_box.clear()
        search_box.send_keys(keyword)
        search_box.send_keys(Keys.RETURN)
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div[data-qa-locator="product-item"]')))
    except:
        driver.quit()
        return []

    sort_param = ''
    if sort_choice == "Top Sale":
        sort_param = 'pop'
    elif sort_choice == "Newest":
        sort_param = 'new'

    if sort_param:
        current_url = driver.current_url
        if 'sort=' in current_url:
            current_url = re.sub(r'sort=[^&]*', f'sort={sort_param}', current_url)
        else:
            current_url += f"&sort={sort_param}"

        try:
            old_element = driver.find_element(By.CSS_SELECTOR, 'div[data-qa-locator="product-item"]')
        except:
            old_element = None

        driver.get(current_url)

        if old_element:
            try:
                wait.until(EC.staleness_of(old_element))
                wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, 'div[data-qa-locator="product-item"]')))
            except:
                pass

    result_list = []
    seen_links = set()

    for page in range(1, max_pages + 1):
        time.sleep(2)
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        products = soup.find_all('div', {'data-qa-locator': 'product-item'})

        for product in products:
            link_tag = product.find('a', href=True)
            link = 'https:' + link_tag['href'] if link_tag else 'N/A'
            if link in seen_links:
                continue
            seen_links.add(link)

            name = product.find('div', class_='RfADt')
            price = product.find('span', class_='ooOxS')
            name_text = name.text.strip() if name else 'N/A'
            price_text = price.text.strip() if price else '0'
            try:
                price_val = float(re.sub(r'[^\d.]', '', price_text))
            except:
                price_val = 0.0

            sold = '0 sold'
            for span in product.find_all('span'):
                if span.text and 'sold' in span.text.lower():
                    sold = span.text.strip()
                    break

            result_list.append([name_text, price_val, sold, link])

        try:
            pagination_links = driver.find_elements(By.CSS_SELECTOR, 'li.ant-pagination-item')
            for page_link in pagination_links:
                if page_link.text == str(page + 1):
                    driver.execute_script("arguments[0].click();", page_link)
                    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div[data-qa-locator="product-item"]')))
                    break
            else:
                break
        except:
            break

    driver.quit()
    original_data = result_list.copy()
    recent_data = result_list.copy()
    return result_list

# The rest of the GUI code omitted for brevity but included in your actual code
